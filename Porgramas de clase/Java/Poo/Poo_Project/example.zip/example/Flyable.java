package example;

interface Flyable {
    int MAX_HEIGHT = 100;
    void rise();
    void descend();
    double getHeight();
}
