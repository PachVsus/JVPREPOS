package example;

public class Man {
    public void think() {
        System.out.println("I'm thinking...");
    }
}
